/* FILE NAME: u_ball.c
 * PURPOSE: -
 * PROGRAMMER: ME3
 * DATE: 08.06.2026
 */

#include "units.h"

typedef struct tagUNIT_BALL me3UNIT_BALL;
struct tagUNIT_BALL
{
  me3UNIT_BASE_FIELDS;
  VEC Pos;
  me3PRIM Bl;
};

static VOID ME3_UnitInit(me3UNIT_BALL *Uni, me3ANIM *Ani)
{
  ME3_RndPrimCreateSphere(&Uni->Bl, 5, 20, 10);
  Uni->Pos = VecSet(Rnd1(), Rnd1(), Rnd1());
}

static VOID ME3_UnitResponse(me3UNIT_BALL *Uni, me3ANIM *Ani)
{
  DBL SpeedX, SpeedY;
  SpeedX = SpeedY = 0;

  if ((Ani->Keys['D'] == 1) || (Ani->Keys[VK_RIGHT] == 1))
    SpeedX = 2;
  if ((Ani->Keys['A'] == 1) || (Ani->Keys[VK_LEFT] == 1))
    SpeedX = -2;
  if ((Ani->Keys['S'] == 1) || (Ani->Keys[VK_DOWN] == 1))
    SpeedY = -2;
  if ((Ani->Keys['W'] == 1) || (Ani->Keys[VK_UP] == 1))
    SpeedY = 2;
  Uni->Pos.X += SpeedX * Ani->DeltaTime;
  Uni->Pos.Y += SpeedY * Ani->DeltaTime;
}

static VOID ME3_UnitRender(me3UNIT_BALL *Uni, me3ANIM *Ani, me3PRIM *sph)
{
  ME3_RndPrimDraw(&Uni->Bl, MatrTranslate(Uni->Pos));
}

static VOID ME3_UnitClose(me3UNIT_BALL *Uni, me3ANIM *Ani)
{
  ME3_RndPrimFree(&Uni->Bl);
}


me3UNIT * ME3_UnitCreateBall( VOID )
{
  me3UNIT *Uni;
 
  if ((Uni = ME3_AnimUnitCreate(sizeof(me3UNIT_BALL))) == NULL)/*create empty struct*/
    return NULL;

  Uni->Init = (VOID *)ME3_UnitInit;
  Uni->Close = (VOID *)ME3_UnitClose;
  Uni->Render = (VOID *)ME3_UnitRender;
  Uni->Response = (VOID *)ME3_UnitResponse;

  return Uni;
}